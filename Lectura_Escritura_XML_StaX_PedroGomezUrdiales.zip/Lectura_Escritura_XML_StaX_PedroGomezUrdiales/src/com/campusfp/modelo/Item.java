package com.campusfp.modelo;

public class Item {
    private String date;
    private String nombre;
    private String ciudad;
    private String salario;
    

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    public String getMode() {
        return nombre;
    }
    public void setMode(String mode) {
        this.nombre = mode;
    }
    public String getUnit() {
        return ciudad;
    }
    public void setUnit(String unit) {
        this.ciudad = unit;
    }
    public String getCurrent() {
        return salario;
    }
    public void setCurrent(String current) {
        this.salario = current;
    }

	@Override
	public String toString() {
		return "Item [nombre=" + nombre + ", ciudad=" + ciudad + ", salario=" + salario + "]";
	}

	
}