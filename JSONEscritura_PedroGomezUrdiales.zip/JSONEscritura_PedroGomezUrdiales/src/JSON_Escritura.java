import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSON_Escritura {
  public static void main(String[] args) {

		JSONObject obj = new JSONObject();
		obj.put("Nombre", "ANTONINO");
		obj.put("Ciudad", "CASTELLON");
		obj.put("Salario", "1500�");

		try {

			FileWriter file = new FileWriter("C:\\Users\\pedro\\eclipse-workspace\\JSONEscritura_PedroGomezUrdiales\\prueba.json");
			file.write(obj.toJSONString());
			file.flush();
			file.close();

		} catch (IOException e) {
			
		}

		System.out.print(obj);

	}

}